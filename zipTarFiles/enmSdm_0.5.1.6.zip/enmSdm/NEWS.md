enmSdm 0.5.1.6
coordPrecision() handles coordinates in DMS format

enmSdm 0.5.1.5
Add Robinson projection to getCRS()

enmSdm 0.5.1.3
Recompiled for R 4.0.0

enmSdm 0.5.1.2
trainBrt() parallelized
trainMaxEnt() parallelized

enmSdm 0.5.0.4
trainByCrossValid() handles non-converged models

enmSdm 0.5.0.3
bioticVelocity() can correct for non-shared land mass
Fix bug in getCRS()

enmSdm 0.5.0.2
Fix bug in bioticVelocity()

enmSdm 0.5.0.1
Fix bug in spatialCorrForValues()

enmSdm 0.5.0.0
Fix bug in predictMaxEnt()

enmSdm 0.4.0.5
trainMaxEnt() and trainMaxNet() internals harmonized
Made sensible examples for trainXYZ() functions

enmSdm 0.4.0.3
Added function makeCRS() for making custom coordinate reference systems

enmSdm 0.4.0.2
Added function decimalToDms() for converting decimal coordinates to degrees-minutes-seconds format
Fixed bug in spatialCorrForPoints() when supplying distance bins in km

enmSdm 0.4.0.1
Fixed bug in coordPrecision() when supplied value was NA.

enmSdm 0.4.0.0
Fixed bug in elimCellDups() when there were no cell duplicates.