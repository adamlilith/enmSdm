enmSdm 0.4.0.1
Fixed bug in coordPrecision() when supplied value was NA.

enmSdm 0.4.0.0
Fixed bug in elimCellDups() when there were no cell duplicates.