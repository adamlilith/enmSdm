enmSdm 0.4.0.0
Fixed bug in elimCellDups() when there were no cell duplicates.